import { BBB } from "./config.mjs";
import { BBBActor, BBBItem } from "./documents.mjs";
import { BBBActorSheet, BBBItemSheet } from "./sheets.mjs";
import * as R from "./rolls.mjs";

Hooks.once("init", () => {
  console.log("BBB | Iniciando Big Bang Breaker");
  CONFIG.BBB = BBB;
  CONFIG.Actor.documentClass = BBBActor;
  CONFIG.Item.documentClass = BBBItem;
  CONFIG.Combat.initiative = { formula: "1d20", decimals: 0 };

  // Condiciones de estado
  CONFIG.statusEffects = BBB.CONDICIONES.map(([id, name, img]) => ({ id, name, img }));
  CONFIG.statusEffects.push({ id: "dead", name: "Fuera de combate", img: "icons/svg/unconscious.svg" });
  CONFIG.specialStatusEffects.DEFEATED = "dead";

  // Hojas
  const ActorsCol = foundry.documents?.collections?.Actors ?? Actors;
  const ItemsCol = foundry.documents?.collections?.Items ?? Items;
  ActorsCol.unregisterSheet("core", foundry.appv1?.sheets?.ActorSheet ?? ActorSheet);
  ItemsCol.unregisterSheet("core", foundry.appv1?.sheets?.ItemSheet ?? ItemSheet);
  ActorsCol.registerSheet("bbb", BBBActorSheet, { types: ["argonauta", "pnj"], makeDefault: true, label: "Ficha BBB" });
  ItemsCol.registerSheet("bbb", BBBItemSheet, { makeDefault: true, label: "Objeto BBB" });

  // Parcial reutilizable: fila de objeto
  Handlebars.registerPartial("bbbItemRow", `
    <li class="item item-row" data-item-id="{{item.id}}">
      <img class="item-img" src="{{item.img}}" width="22" height="22"/>
      <a class="item-name" data-action="item-use" title="Usar / tirar">{{item.name}}</a>
      <span class="item-meta">{{meta}}</span>
      {{#if cdField}}<input class="item-field cd" type="number" min="1" max="10" data-field="system.cd" value="{{item.system.cd}}" title="Dado de enfriamiento (1 = listo)"/>{{/if}}
      <span class="item-ctl">
        {{#if item.system.recarga.max}}<a data-action="recargar" title="Recargar"><i class="fas fa-rotate"></i></a>{{/if}}
        {{#if toggle}}<a data-action="item-toggle" title="Equipar" class="{{#if item.system.equipada}}on{{/if}}"><i class="fas fa-power-off"></i></a>{{/if}}
        <a data-action="item-edit" title="Editar"><i class="fas fa-edit"></i></a>
        <a data-action="item-delete" title="Borrar"><i class="fas fa-trash"></i></a>
      </span>
    </li>`);
  Handlebars.registerHelper("bbbMeta", (item) => {
    const s = item.system, n = (v) => Number(v) || 0;
    const tipo = BBB.TIPOS_DANO[s.tipoDano]?.label ?? "";
    switch (item.type) {
      case "arma": return `${s.alcance} · ${s.dano} ${tipo} · ${n(s.pau)} PAU${n(s.recarga?.max) ? ` · ${n(s.recarga.value)}/${n(s.recarga.max)}` : ""}`;
      case "habilidad": return `${n(s.pau) ? `${n(s.pau)} PAU` : BBB.ACTIVACIONES[s.activacion] ?? ""}${n(s.tde) ? ` · TdE ${n(s.tde)}` : ""}${n(s.usos?.max) ? ` · ${n(s.usos.value)}/${n(s.usos.max)}` : ""} · M${n(s.modulos)}`;
      case "codigo": return `RAM ${n(s.ram)} · ${n(s.pau)} PAU${n(s.tde) ? ` · TdE ${n(s.tde)}` : ""}`;
      case "dote": return BBB.ACTIVACIONES[s.activacion] ?? "";
      case "talento": return n(s.valor) >= 0 ? `+${n(s.valor)}` : `${n(s.valor)}`;
      case "cyberware": return `${n(s.ranuras)} ranura(s)`;
      case "armadura": return `G ${n(s.guardia)} · F ${n(s.firewall)} · B ${n(s.blindaje)} · T${n(s.tier)}`;
      case "equipo": return `×${n(s.cantidad)}`;
      default: return "";
    }
  });
  Handlebars.registerHelper("bbbSgn", (n) => (Number(n) >= 0 ? `+${Number(n)}` : `${Number(n)}`));
  Handlebars.registerHelper("bbbPct", (v, m) => (Number(m) > 0 ? Math.max(0, Math.min(100, (Number(v) / Number(m)) * 100)) : 0));
});

// Turno: restaurar PA y reducir dados de enfriamiento (solo lo ejecuta el DJ)
Hooks.on("combatTurnChange", (combat) => {
  if (!game.user.isGM) return;
  combat.combatant?.actor?.onTurnStart?.();
});
Hooks.on("combatStart", (combat) => {
  if (!game.user.isGM) return;
  combat.combatant?.actor?.onTurnStart?.();
});

// Botones de las tarjetas de chat (delegado, funciona igual en v12 y v13)
document.addEventListener("click", async (ev) => {
  const btn = ev.target.closest?.("button.bbb-roll-dano, button.bbb-apply, button.bbb-roll-formula");
  if (!btn) return;
  ev.preventDefault();
  if (btn.classList.contains("bbb-roll-dano")) {
    const actor = await fromUuid(btn.dataset.actor);
    const item = actor?.items?.get(btn.dataset.item);
    if (actor && item) return R.rollDano(actor, item, { crit: btn.dataset.crit === "1" });
  } else if (btn.classList.contains("bbb-roll-formula")) {
    const actor = await fromUuid(btn.dataset.actor);
    if (actor) return R.rollDanoFormula(actor, { nombre: btn.dataset.nombre, formula: btn.dataset.formula, tipo: btn.dataset.tipo, etiquetas: btn.dataset.et });
  } else {
    const d = btn.dataset;
    let tokens = [...game.user.targets];
    if (!tokens.length) tokens = canvas.tokens?.controlled ?? [];
    if (!tokens.length) return ui.notifications.warn("Marca un objetivo (T) o selecciona un token.");
    for (const tk of tokens) {
      const a = tk.actor;
      if (!a) continue;
      if (!a.isOwner) { ui.notifications.warn(`No tienes permiso sobre ${a.name}: pide al DJ que aplique el daño.`); continue; }
      await a.applyDamage(Number(d.dmg), { tipo: d.tipo, at: Number(d.at), mult: Number(d.mult) });
    }
  }
});
