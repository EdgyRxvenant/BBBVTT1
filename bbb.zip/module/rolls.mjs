import { BBB } from "./config.mjs";

const num = (v) => Number(v) || 0;
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const sgn = (n) => (n >= 0 ? `+${n}` : `${n}`);
const tipoLabel = (t) => BBB.TIPOS_DANO[t]?.label ?? t ?? "";

/* ------------------------------------------------------------------ */
/*  Diálogo de modificadores                                           */
/* ------------------------------------------------------------------ */
/**
 * Pregunta Determinación / Desesperación / Fortuna / Infortunio y extras.
 * Shift+clic omite el diálogo.
 */
async function pedirMods(titulo, { dc = false, legend = false, hack = false, det = 0, des = 0 } = {}, event = null) {
  const base = { det, des, luck: "", bonus: 0, dc: null, legend: false, hackeo: "electrocutar" };
  if (event?.shiftKey) return base;
  const campo = (label, input) => `<div class="form-group"><label>${label}</label><div class="form-fields">${input}</div></div>`;
  const content = `<div class="bbb-dialog">
    ${campo("Determinación (+1d6)", `<input type="number" name="det" value="${det}" min="0">`)}
    ${campo("Desesperación (−1d6)", `<input type="number" name="des" value="${des}" min="0">`)}
    ${campo("Fortuna / Infortunio", `<select name="luck"><option value="">Ninguno</option><option value="fortuna">Fortuna (2d20, mejor)</option><option value="infortunio">Infortunio (2d20, peor)</option></select>`)}
    ${campo("Bonificación extra", `<input type="number" name="bonus" value="0">`)}
    ${dc ? campo("Dificultad (opcional)", `<input type="number" name="dc" value="">`) : ""}
    ${legend ? campo("Tirada legendaria (1d20 plano)", `<input type="checkbox" name="legend">`) : ""}
    ${hack ? campo("Hackeo", `<select name="hackeo">
        <option value="electrocutar">Electrocutar (1d6 Electromagnético)</option>
        <option value="destruir">Destruir Sistemas (Mermado y Alentado)</option>
        <option value="inhibir">Inhibir Armamento (salvación TECH)</option>
        <option value="vulnerar">Vulnerar Sistemas (información)</option>
        <option value="manipular">Manipular Tecnología</option></select>`) : ""}
  </div>`;
  const leer = (el) => ({
    det: num(el.det?.value), des: num(el.des?.value), luck: el.luck?.value ?? "", bonus: num(el.bonus?.value),
    dc: el.dc && el.dc.value !== "" ? num(el.dc.value) : null, legend: !!el.legend?.checked,
    hackeo: el.hackeo?.value ?? "electrocutar"
  });
  const DV2 = foundry.applications?.api?.DialogV2;
  if (DV2) {
    return DV2.wait({
      window: { title: titulo }, content, rejectClose: false, modal: false,
      buttons: [{ action: "ok", label: "Tirar", default: true, callback: (ev, btn) => leer(btn.form.elements) }]
    });
  }
  return new Promise((res) => {
    new Dialog({
      title: titulo, content: `<form>${content}</form>`,
      buttons: { ok: { label: "Tirar", callback: (html) => res(leer(html[0].querySelector("form").elements)) } },
      default: "ok", close: () => res(null)
    }).render(true);
  });
}

/* ------------------------------------------------------------------ */
/*  Núcleo: 1d20 + bonificaciones ± pool de d6                         */
/* ------------------------------------------------------------------ */
/**
 * Determinación (+) y Desesperación (−) se cancelan 1 a 1; el remanente tira
 * ese número de d6 y se toma el más alto (suma o resta). Fortuna/Infortunio: 2d20 y mejor/peor.
 */
async function tirarD20({ bonus = 0, det = 0, des = 0, luck = "", legend = false }) {
  const rolls = [];
  if (legend) {
    const r = await new Roll("1d20").evaluate();
    return { rolls: [r], dados: [r.total], natural: r.total, pool: [], poolVal: 0, bonus: 0, total: r.total, legend: true };
  }
  const f = luck === "fortuna" ? "2d20kh" : luck === "infortunio" ? "2d20kl" : "1d20";
  const r20 = await new Roll(f).evaluate();
  rolls.push(r20);
  const dados = r20.dice[0].results.map((x) => x.result);
  const net = num(det) - num(des);
  let pool = [], poolVal = 0;
  if (net !== 0) {
    const rp = await new Roll(`${Math.abs(net)}d6`).evaluate();
    rolls.push(rp);
    pool = rp.dice[0].results.map((x) => x.result);
    poolVal = Math.max(...pool) * Math.sign(net);
  }
  return { rolls, dados, natural: r20.total, pool, poolVal, bonus, total: r20.total + num(bonus) + poolVal, luck, net };
}

function desglose(t) {
  if (t.legend) return `1d20 plano <b>[${t.natural}]</b>`;
  let s = t.luck ? `2d20 [${t.dados.join(", ")}] → <b>${t.natural}</b>` : `1d20 <b>[${t.natural}]</b>`;
  if (t.bonus) s += ` ${sgn(t.bonus)}`;
  if (t.pool.length) s += ` ${t.poolVal >= 0 ? "+" : "−"} ${Math.abs(t.poolVal)} <small>(${t.net > 0 ? "Det." : "Des."} ${t.pool.join(", ")})</small>`;
  return s;
}

function card({ actor, titulo, subtitulo = "", cuerpo = "", t = null, rolls = [] }) {
  const total = t ? `<div class="bbb-total">${t.total}</div>` : "";
  const html = `<div class="bbb-card">
    <header class="bbb-card-head"><img src="${esc(actor.img)}" width="28" height="28"/><div><h3>${esc(titulo)}</h3><span>${subtitulo}</span></div></header>
    <div class="bbb-card-body">${t ? `<div class="bbb-roll-line">${desglose(t)}</div>${total}` : ""}${cuerpo}</div></div>`;
  return ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }), content: html,
    rolls: t ? t.rolls : rolls, sound: t || rolls.length ? CONFIG.sounds.dice : null
  });
}

const objetivos = () => [...game.user.targets];

/* ------------------------------------------------------------------ */
/*  Tiradas de atributo / salvación / talento                          */
/* ------------------------------------------------------------------ */
export async function rollAtributo(actor, attr, event, salvacion = false) {
  const nombre = BBB.ATRIBUTOS[attr];
  const titulo = salvacion ? `Salvación de ${BBB.ATRIBUTOS_ABBR[attr]}` : `Tirada de ${nombre}`;
  const m = await pedirMods(titulo, { dc: true }, event);
  if (!m) return;
  const t = await tirarD20({ bonus: num(actor.system.atributos[attr]) + m.bonus, det: m.det, des: m.des, luck: m.luck });
  let cuerpo = "";
  if (m.dc != null) cuerpo = `<div class="bbb-result ${t.total >= m.dc ? "ok" : "fail"}">${t.total >= m.dc ? "Éxito" : "Fallo"} <small>(Dificultad ${m.dc})</small></div>`;
  return card({ actor, titulo, subtitulo: `${nombre} ${sgn(num(actor.system.atributos[attr]))}`, cuerpo, t });
}
export const rollSalvacion = (actor, attr, event) => rollAtributo(actor, attr, event, true);

export async function rollTalento(actor, item, event) {
  const valor = item ? num(item.system.valor) : 0;
  const titulo = item ? item.name : "Tirada de talento";
  const m = await pedirMods(titulo, { dc: true, legend: true }, event);
  if (!m) return;
  const t = await tirarD20({ bonus: valor + m.bonus, det: m.det, des: m.des, luck: m.luck, legend: m.legend });
  let cuerpo = "";
  if (m.dc != null) {
    const ok = t.total >= m.dc;
    const dura = !ok && m.dc - t.total >= BBB.DECISION_DIFICIL;
    cuerpo = `<div class="bbb-result ${ok ? "ok" : "fail"}">${ok ? "Éxito" : "Fallo"} <small>(Dificultad ${m.dc})</small>${dura ? "<br><b>Decisión difícil</b>" : ""}</div>`;
  }
  return card({ actor, titulo, subtitulo: item ? `Talento ${sgn(valor)}` : "Talento", cuerpo, t });
}

/* ------------------------------------------------------------------ */
/*  Ataque y daño                                                      */
/* ------------------------------------------------------------------ */
export async function rollAtaque(actor, item, event) {
  const s = item.system;
  const et = String(s.etiquetas ?? "");
  const det = /\bpreciso\b/i.test(et) ? 1 : 0;
  const des = /\bimpreciso\b/i.test(et) ? 1 : 0;
  const m = await pedirMods(`Ataque: ${item.name}`, { det, des }, event);
  if (!m) return;
  if (num(s.pau) > 0 && actor.system.pa) await actor.gastarPA(num(s.pau));
  if (num(s.recarga?.max) > 0) {
    if (num(s.recarga.value) <= 0) ui.notifications.warn(`${item.name} necesita recarga.`);
    else await item.update({ "system.recarga.value": num(s.recarga.value) - 1 });
  }
  const bono = num(actor.system.derived.bonoAtaque) + num(s.bonoAtaque) + m.bonus;
  const t = await tirarD20({ bonus: bono, det: m.det, des: m.des, luck: m.luck });
  const crit = t.total > BBB.CRITICO_SOBRE;
  const tg = objetivos().map((tk) => {
    const g = tk.actor?.system?.derived?.guardia;
    return { nombre: tk.name, g, hit: g == null ? null : t.total >= g };
  });
  const lista = tg.length
    ? `<ul class="bbb-targets">${tg.map((x) => `<li class="${x.hit ? "ok" : x.hit === false ? "fail" : ""}">${esc(x.nombre)}: ${x.hit == null ? "—" : x.hit ? "Impacta" : "Falla"} <small>(Guardia ${x.g ?? "?"})</small></li>`).join("")}</ul>`
    : "";
  const cuerpo = `${crit ? `<div class="bbb-crit">¡CRÍTICO!</div>` : ""}${lista}
    <button class="bbb-roll-dano" data-actor="${actor.uuid}" data-item="${item.id}" data-crit="${crit ? 1 : 0}"><i class="fas fa-burst"></i> Tirar daño${crit ? " (crítico)" : ""}</button>`;
  return card({ actor, titulo: item.name, subtitulo: `${esc(s.alcance)} · ${num(s.pau)} PAU · ${esc(et)}`, cuerpo, t });
}

function rollData(actor) {
  const a = actor.system.atributos, d = actor.system.derived ?? {};
  return { for: num(a.for), dez: num(a.dez), eng: num(a.eng), con: num(a.con), tech: num(a.tech), adt: num(d.adt), nivel: num(actor.system.nivel) };
}

export async function rollDano(actor, item, { crit = false } = {}) {
  const s = item.system;
  if (!s.dano) return ui.notifications.warn(`${item.name} no tiene fórmula de daño.`);
  return rollDanoFormula(actor, {
    nombre: item.name, formula: s.dano, tipo: s.tipoDano, etiquetas: s.etiquetas, crit,
    atributos: item.type === "arma" && s.sumaAtributos !== false ? (s.melee ? "caC" : "rango") : ""
  });
}

export async function rollDanoFormula(actor, { nombre, formula, tipo = "", etiquetas = "", crit = false, atributos = "" }) {
  const r = await new Roll(formula, rollData(actor)).evaluate();
  let base = r.total * (crit ? 2 : 1);
  const d = actor.system.derived ?? {};
  let extra = 0;
  const partes = [`${r.formula} = ${r.total}${crit ? " ×2" : ""}`];
  if (actor.type === "argonauta") {
    if (atributos === "caC") { extra += num(d.danoCaC); partes.push(`FOR/DEZ ${sgn(num(d.danoCaC))}`); }
    else if (atributos === "rango") { extra += num(d.danoRango); partes.push(`CON/DEZ ${sgn(num(d.danoRango))}`); }
    else if (atributos === "onirico") { extra += num(d.danoOnirico); partes.push(`ENG ${sgn(num(d.danoOnirico))}`); }
    if (crit) { extra += num(d.danoCritico); partes.push(`Crítico CON ${sgn(num(d.danoCritico))}`); }
  }
  const total = Math.max(0, base + extra);
  const at = /\bAT\s*2\b/i.test(etiquetas) ? 2 : /\bAT\s*1\b/i.test(etiquetas) ? 1 : 0;
  const cuerpo = `<div class="bbb-total">${total}</div>
    <div class="bbb-dmg-type">${esc(tipoLabel(tipo))}${at ? ` · AT${at}` : ""}</div>
    <div class="bbb-roll-line"><small>${esc(partes.join(" · "))}</small></div>
    <div class="bbb-buttons">
      <button class="bbb-apply" data-dmg="${total}" data-tipo="${esc(tipo)}" data-at="${at}" data-mult="1">Aplicar</button>
      <button class="bbb-apply" data-dmg="${total}" data-tipo="${esc(tipo)}" data-at="${at}" data-mult="0.5">Mitad</button>
    </div><small>Se aplica a los objetivos marcados (o tokens seleccionados).</small>`;
  return card({ actor, titulo: `${nombre} — daño`, subtitulo: esc(tipoLabel(tipo)), cuerpo, rolls: [r] });
}

/* ------------------------------------------------------------------ */
/*  Habilidades, códigos y dotes                                       */
/* ------------------------------------------------------------------ */
export async function usarHabilidad(actor, item, event) {
  const s = item.system;
  const usable = item.type !== "dote";
  if (usable && num(s.cd) > 1 && !event?.shiftKey) {
    return ui.notifications.warn(`${item.name} está en enfriamiento (dado en ${s.cd}). Shift+clic para ignorar.`);
  }
  if (item.type === "habilidad" && num(s.usos?.max) > 0) {
    if (num(s.usos.value) <= 0) return ui.notifications.warn(`${item.name} no tiene cargas.`);
    await item.update({ "system.usos.value": num(s.usos.value) - 1 });
  }
  if (usable && num(s.pau) > 0 && actor.system.pa) await actor.gastarPA(num(s.pau));
  if (usable && num(s.tde) > 0) {
    const tde = Math.max(0, num(s.tde) - num(actor.system.derived?.tdeReduccion));
    const tope = item.type === "codigo" ? 10 : 6;
    await item.update({ "system.cd": Math.min(tope, 1 + tde) });
  }
  const tags = [];
  if (usable && num(s.pau)) tags.push(`${num(s.pau)} PAU`);
  if (usable && num(s.tde)) tags.push(`TdE ${num(s.tde)}`);
  if (s.alcance) tags.push(esc(s.alcance));
  if (item.type === "codigo") tags.push(`RAM ${num(s.ram)}`);
  if (s.limite) tags.push(esc(s.limite));
  let cuerpo = `<p>${esc(s.descripcion).replace(/\n/g, "<br>")}</p>`;
  if (s.dano) {
    cuerpo += `<button class="bbb-roll-dano" data-actor="${actor.uuid}" data-item="${item.id}" data-crit="0"><i class="fas fa-burst"></i> Tirar daño (${esc(s.dano)})</button>`;
  }
  return card({ actor, titulo: item.name, subtitulo: tags.join(" · "), cuerpo });
}

export function cardItem(actor, item) {
  return card({ actor, titulo: item.name, cuerpo: `<p>${esc(item.system.descripcion).replace(/\n/g, "<br>")}</p>` });
}

/* ------------------------------------------------------------------ */
/*  Hackeo                                                             */
/* ------------------------------------------------------------------ */
const HACKEOS = {
  electrocutar: ["Electrocutar", "Descarga eléctrica: 1d6 de daño Electromagnético que ignora el Blindaje."],
  destruir: ["Destruir Sistemas", "El objetivo queda Mermado y Alentado hasta el final de su siguiente turno."],
  inhibir: ["Inhibir Armamento", "Un arma de rango del objetivo: si falla una salvación de TECH, su siguiente ataque con ella tiene +2 Desesperación."],
  vulnerar: ["Vulnerar Sistemas", "Conoces estadísticas, habilidades e información relevante del objetivo."],
  manipular: ["Manipular Tecnología", "Enciendes o apagas tecnología que no sea hardware militar."]
};

export async function rollHackeo(actor, event) {
  const m = await pedirMods("Hackear", { hack: true }, event);
  if (!m) return;
  if (actor.system.pa) await actor.gastarPA(1);
  const bono = num(actor.system.derived.bonoHack) + m.bonus;
  const t = await tirarD20({ bonus: bono, det: m.det, des: m.des, luck: m.luck });
  const [nombre, efecto] = HACKEOS[m.hackeo] ?? HACKEOS.electrocutar;
  const tg = objetivos().map((tk) => {
    const f = tk.actor?.system?.derived?.firewall;
    return { nombre: tk.name, f, hit: f == null ? null : t.total >= f };
  });
  const lista = tg.length
    ? `<ul class="bbb-targets">${tg.map((x) => `<li class="${x.hit ? "ok" : x.hit === false ? "fail" : ""}">${esc(x.nombre)}: ${x.hit == null ? "—" : x.hit ? "Hackeo exitoso" : "Falla"} <small>(Firewall ${x.f ?? "?"})</small></li>`).join("")}</ul>`
    : "";
  let cuerpo = `${lista}<p><b>${nombre}.</b> ${efecto}</p>`;
  if (m.hackeo === "electrocutar") {
    cuerpo += `<button class="bbb-roll-formula" data-actor="${actor.uuid}" data-formula="1d6" data-tipo="electromagnetico" data-nombre="Electrocutar" data-et="AT1"><i class="fas fa-bolt"></i> Tirar 1d6</button>`;
  }
  return card({ actor, titulo: "Hackear", subtitulo: `Tirada de Hacking ${sgn(bono)} · TECH ${sgn(num(actor.system.atributos.tech))}`, cuerpo, t });
}

/* ------------------------------------------------------------------ */
/*  Tirada de suerte (Escudo a 0) → Heridas de Batalla                 */
/* ------------------------------------------------------------------ */
export async function rollSuerte(actor) {
  const previas = num(actor.system.heridas);
  const total = Math.min(8, previas + 1);
  const n = Math.min(4, total);
  const r = await new Roll(`${n}d6`).evaluate();
  const vals = r.dice[0].results.map((x) => x.result);
  const res = Math.min(...vals);
  const rolls = [r];
  const act = async (id) => actor.toggleStatusEffect(id, { active: true });
  let titulo = "", texto = "";
  if (res === 6) {
    titulo = "Herida superficial"; texto = "Una herida superficial sobre tu cuerpo o armadura. Estás <b>Mermado</b> hasta el final de tu siguiente turno."; await act("mermado");
  } else if (res >= 4) {
    titulo = "Equipo destrozado";
    const s = await new Roll("1d6").evaluate(); rolls.push(s);
    texto = s.total >= 5 ? `[${s.total}] <b>Arma:</b> elige un arma equipada y destrúyela.`
      : s.total >= 3 ? `[${s.total}] <b>Cyberware:</b> elige dos cyberware equipados y destrúyelos.`
      : `[${s.total}] <b>Módulo de habilidad:</b> elige una habilidad o código equipado; queda destruido hasta reparar la armadura.`;
  } else if (res >= 2) {
    titulo = "Fallo repentino";
    const s = await new Roll("1d6").evaluate(); rolls.push(s);
    if (s.total >= 5) { texto = `[${s.total}] <b>Fallo de armadura:</b> Aturdido hasta el final de tu siguiente turno.`; await act("aturdido"); }
    else if (s.total >= 3) { texto = `[${s.total}] <b>Blindaje perforado:</b> estás Vulnerable.`; await act("vulnerable"); }
    else { texto = `[${s.total}] <b>Catástrofe:</b> Aturdido y Vulnerable.`; await act("aturdido"); await act("vulnerable"); }
  } else {
    titulo = "Impacto letal"; texto = "El enemigo impactó tus puntos vitales. Realiza una <b>salvación de FOR</b>: si tienes éxito quedas Aturdido; si fallas, quedas fuera de combate.";
  }
  await actor.update({ "system.heridas": total });
  const cuerpo = `<div class="bbb-total">${res}</div><div class="bbb-roll-line"><small>${n}d6 [${vals.join(", ")}] → el más bajo · Herida de Batalla #${total}</small></div>
    <h4>${titulo}</h4><p>${texto}</p>`;
  return card({ actor, titulo: "Tirada de suerte", subtitulo: "Escudo destruido", cuerpo, rolls });
}
