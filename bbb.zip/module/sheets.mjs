import { BBB } from "./config.mjs";

const ActorSheetBase = foundry.appv1?.sheets?.ActorSheet ?? ActorSheet;
const ItemSheetBase = foundry.appv1?.sheets?.ItemSheet ?? ItemSheet;
const num = (v) => Number(v) || 0;

const contador = (valor, total) => Array.from({ length: total }, (_, i) => ({ i, on: i < num(valor) }));

export class BBBActorSheet extends ActorSheetBase {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["bbb", "sheet", "actor"],
      width: 940,
      height: 880,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "combate", group: "primary" }],
      scrollY: [".tab"]
    });
  }

  get template() {
    return `systems/bbb/templates/actor-${this.actor.type}.hbs`;
  }

  async getData(options) {
    const ctx = await super.getData(options);
    const actor = this.actor;
    ctx.system = actor.system;
    ctx.derived = actor.system.derived;
    ctx.editable = this.isEditable;
    ctx.config = BBB;
    ctx.especies = Object.entries(BBB.ESPECIES).map(([k, v]) => ({ key: k, nombre: v.nombre }));
    ctx.clases = Object.entries(BBB.CLASES).map(([k, v]) => ({ key: k, nombre: v.nombre }));
    ctx.tiposDano = Object.entries(BBB.TIPOS_DANO).map(([k, v]) => ({ key: k, label: v.label }));
    ctx.atributos = Object.entries(BBB.ATRIBUTOS).map(([k, label]) => ({
      key: k, label, abbr: BBB.ATRIBUTOS_ABBR[k], value: actor.system.atributos[k]
    }));
    ctx.muerte = contador(actor.system.muerte, 5);
    ctx.heridas = contador(actor.system.heridas, 8);
    ctx.estres = contador(actor.system.estres, 9).map((x) => ({ ...x, extra: x.i >= 7 }));

    const items = [...actor.items].sort((a, b) => (a.sort ?? 0) - (b.sort ?? 0));
    const by = (t) => items.filter((i) => i.type === t);
    ctx.armas = by("arma");
    ctx.armaduras = by("armadura");
    ctx.habilidades = by("habilidad");
    ctx.codigos = by("codigo");
    ctx.talentos = by("talento");
    ctx.cyberware = by("cyberware");
    ctx.equipo = by("equipo");
    ctx.dotes = Object.entries(BBB.ORIGEN_DOTES)
      .map(([k, label]) => ({ key: k, label, items: by("dote").filter((d) => d.system.origen === k) }))
      .filter((g) => g.items.length);
    ctx.estados = actor.effects.map((e) => ({ id: e.id, name: e.name, img: e.img }));
    return ctx;
  }

  activateListeners(html) {
    super.activateListeners(html);
    html = html instanceof HTMLElement ? $(html) : html;

    // --- Tiradas
    html.find("[data-roll-attr]").on("click", (ev) => this.actor.rollAtributo(ev.currentTarget.dataset.rollAttr, ev));
    html.find("[data-roll-save]").on("click", (ev) => this.actor.rollSalvacion(ev.currentTarget.dataset.rollSave, ev));
    html.find("[data-action=hack]").on("click", (ev) => this.actor.rollHackeo(ev));
    html.find("[data-action=suerte]").on("click", () => this.actor.rollSuerte());
    html.find("[data-action=talento-libre]").on("click", async (ev) => {
      const { rollTalento } = await import("./rolls.mjs");
      rollTalento(this.actor, null, ev);
    });

    // --- Objetos
    const getItem = (el) => this.actor.items.get(el.closest("[data-item-id]")?.dataset.itemId);
    html.find("[data-action=item-use]").on("click", (ev) => getItem(ev.currentTarget)?.use(ev));
    html.find("[data-action=item-edit]").on("click", (ev) => getItem(ev.currentTarget)?.sheet.render(true));
    html.find("[data-action=item-delete]").on("click", async (ev) => {
      const it = getItem(ev.currentTarget);
      if (it) await it.delete();
    });
    html.find("[data-action=item-create]").on("click", (ev) => {
      const t = ev.currentTarget.dataset;
      const data = { name: `Nuevo ${t.label ?? t.type}`, type: t.type };
      if (t.origen) data.system = { origen: t.origen };
      return this.actor.createEmbeddedDocuments("Item", [data], { renderSheet: true });
    });
    html.find("[data-action=item-toggle]").on("click", (ev) => {
      const it = getItem(ev.currentTarget);
      if (it) it.update({ "system.equipada": !it.system.equipada });
    });
    html.find(".item-field").on("change", (ev) => {
      const it = getItem(ev.currentTarget);
      const el = ev.currentTarget;
      if (it) it.update({ [el.dataset.field]: el.type === "number" ? num(el.value) : el.value });
    });

    // --- Contadores (muerte, heridas, estrés): clic en la casilla i fija i+1 (o apaga si ya es el valor)
    html.find("[data-counter]").on("click", (ev) => {
      const { counter, index } = ev.currentTarget.dataset;
      const actual = num(foundry.utils.getProperty(this.actor, `system.${counter}`));
      const nuevo = actual === Number(index) + 1 ? Number(index) : Number(index) + 1;
      return this.actor.update({ [`system.${counter}`]: nuevo });
    });

    // --- Condiciones
    html.find("[data-action=estado]").on("change", async (ev) => {
      const id = ev.currentTarget.value;
      if (!id) return;
      await this.actor.toggleStatusEffect(id);
      ev.currentTarget.value = "";
    });
    html.find("[data-action=quitar-efecto]").on("click", (ev) => {
      this.actor.effects.get(ev.currentTarget.dataset.effectId)?.delete();
    });

    // --- Presets de especie y clase
    html.find("[data-preset=especie]").on("change", (ev) => {
      const p = BBB.ESPECIES[ev.currentTarget.value];
      if (!p) return;
      this.actor.update({
        "system.tamano": p.tamano,
        "system.especie": { key: ev.currentTarget.value, nombre: p.nombre, pv: p.pv, pe: p.pe, ps: p.ps, todoPE: p.todoPE }
      });
    });
    html.find("[data-preset=clase]").on("change", (ev) => {
      const p = BBB.CLASES[ev.currentTarget.value];
      if (!p) return;
      this.actor.update({ "system.clase": { key: ev.currentTarget.value, ...p } });
    });

    // --- Reposo: restaurar barras y limpiar contadores
    html.find("[data-action=reposo]").on("click", async () => {
      const a = this.actor.system.aguante;
      await this.actor.update({
        "system.aguante.pv.value": a.pv.max, "system.aguante.pe.value": a.pe.max, "system.aguante.ps.value": a.ps.max,
        "system.muerte": 0, "system.estres": 0
      });
      const ups = this.actor.items.filter((i) => ["habilidad", "codigo"].includes(i.type))
        .map((i) => ({ _id: i.id, "system.cd": 1, ...(i.type === "habilidad" ? { "system.usos.value": i.system.usos.max } : {}) }));
      if (ups.length) await this.actor.updateEmbeddedDocuments("Item", ups);
    });
    html.find("[data-action=recargar]").on("click", (ev) => {
      const it = getItem(ev.currentTarget);
      if (it) it.update({ "system.recarga.value": it.system.recarga.max });
    });
  }
}

export class BBBItemSheet extends ItemSheetBase {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["bbb", "sheet", "item"], width: 540, height: 560
    });
  }
  get template() {
    return "systems/bbb/templates/item.hbs";
  }
  async getData(options) {
    const ctx = await super.getData(options);
    ctx.system = this.item.system;
    ctx.config = BBB;
    ctx.tiposDano = Object.entries(BBB.TIPOS_DANO).map(([k, v]) => ({ key: k, label: v.label }));
    ctx.origenes = Object.entries(BBB.ORIGEN_DOTES).map(([k, label]) => ({ key: k, label }));
    ctx.activaciones = Object.entries(BBB.ACTIVACIONES).map(([k, label]) => ({ key: k, label }));
    ctx.metodos = Object.entries(BBB.METODOS_CODIGO).map(([k, label]) => ({ key: k, label }));
    ctx.is = { [this.item.type]: true };
    return ctx;
  }
}
