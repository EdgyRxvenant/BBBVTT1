import { BBB } from "./config.mjs";
import * as R from "./rolls.mjs";

const num = (v) => Number(v) || 0;

export class BBBActor extends Actor {
  /* -------------------------------------------- */
  /*  Datos derivados                              */
  /* -------------------------------------------- */
  prepareDerivedData() {
    super.prepareDerivedData?.();
    const s = this.system;
    s.derived = {};
    if (this.type === "argonauta") this._deriveArgonauta(s);
    else if (this.type === "pnj") this._derivePNJ(s);
    // Evitar valores por encima del máximo (barras de token)
    for (const k of ["pv", "pe", "ps"]) {
      const p = s.aguante[k];
      p.value = Math.min(num(p.value), num(p.max));
    }
  }

  _deriveArgonauta(s) {
    const a = s.atributos;
    const d = s.derived;
    const nivel = num(s.nivel);
    const adt = BBB.adt(nivel);
    const armor = this.items.find((i) => i.type === "armadura" && i.system.equipada);
    const A = armor?.system ?? null;
    const sp = s.especie, cl = s.clase, b = s.bonos;

    let pv = num(sp.pv) + num(cl.pvBase) + num(cl.pvFor) * num(a.for) + num(cl.pvAdt) * adt + num(A?.pv) + num(b.pv);
    let pe = num(sp.pe) + num(cl.peBase) + num(cl.peFor) * num(a.for) + num(cl.peAdt) * adt + num(A?.pe) + num(b.pe);
    let ps = num(sp.ps) + num(A?.ps) + num(b.ps);
    // ISO: todo el AGUANTE se convierte en PE. Especies con PS (Vulkkönita): el PV de clase pasa a PS.
    if (sp.todoPE) { pe += pv + ps; pv = 0; ps = 0; }
    else if (num(sp.ps) > 0) { ps += pv; pv = 0; }
    s.aguante.pv.max = Math.max(0, pv);
    s.aguante.pe.max = Math.max(0, pe);
    s.aguante.ps.max = Math.max(0, ps);

    d.nivel = nivel;
    d.adt = adt;
    d.tier = BBB.tier(nivel);
    d.guardia = (A ? num(A.guardia) : 6) + num(a.dez) + num(b.guardia);
    d.firewall = (A ? num(A.firewall) : 8) + num(a.tech) + num(b.firewall);
    d.blindaje = Math.min(BBB.BLINDAJE_MAX, num(A?.blindaje) + num(b.blindaje));
    d.radar = (A ? num(A.radar) : 5) + num(b.radar);
    d.velocidad = num(cl.velocidad) + Math.floor(num(a.dez) / 2) + num(A?.velocidad) + num(b.velocidad);
    d.dificultad = num(cl.dificultadBase) + adt + Math.floor(num(a.con) / 2);
    d.bonoAtaque = adt + Math.floor(num(a.con) / 2);
    d.bonoHack = adt + num(a.tech);
    d.modulos = adt + Math.floor(num(a.tech) / 2) + num(A?.modulos) + num(b.modulos);
    d.ranurasCyber = num(A?.cyberware) + Math.floor(num(a.tech) / 2) + num(b.ranuras);
    d.ram = nivel + num(a[s.paradigma] ?? 0);
    d.danoCaC = num(a.for) * 2 + num(a.dez);
    d.danoRango = num(a.con) + num(a.dez);
    d.danoCritico = num(a.con) * 2;
    d.danoOnirico = num(a.eng) * 2;
    d.tdeReduccion = Math.floor(num(a.eng) / 2);
    d.arsenal = num(A?.arsenal) || 3;
    d.armadura = armor?.name ?? "—";
    d.modulosUsados = this.items
      .filter((i) => i.type === "habilidad" && i.system.equipada)
      .reduce((t, i) => t + num(i.system.modulos), 0);
    d.ramUsada = this.items
      .filter((i) => i.type === "codigo" && i.system.equipada)
      .reduce((t, i) => t + num(i.system.ram), 0);
    d.cyberUsado = this.items
      .filter((i) => i.type === "cyberware" && i.system.equipada)
      .reduce((t, i) => t + num(i.system.ranuras), 0);
  }

  _derivePNJ(s) {
    const st = s.stats;
    s.derived = {
      guardia: num(st.guardia), firewall: num(st.firewall), blindaje: Math.min(BBB.BLINDAJE_MAX, num(st.blindaje)),
      radar: num(st.radar), velocidad: num(st.velocidad), dificultad: num(st.dificultad),
      bonoAtaque: 0, bonoHack: num(st.bonoHack), adt: 0, tier: s.tier,
      danoCaC: 0, danoRango: 0, danoCritico: 0, danoOnirico: 0, tdeReduccion: 0
    };
  }

  /* -------------------------------------------- */
  /*  Tiradas                                      */
  /* -------------------------------------------- */
  rollAtributo(attr, event) { return R.rollAtributo(this, attr, event); }
  rollSalvacion(tipo, event) { return R.rollSalvacion(this, tipo, event); }
  rollHackeo(event) { return R.rollHackeo(this, event); }
  rollSuerte() { return R.rollSuerte(this); }

  /* -------------------------------------------- */
  /*  Daño                                         */
  /* -------------------------------------------- */
  _lista(campo) {
    return String(this.system.resistencias?.[campo] ?? "")
      .toLowerCase().split(/[,;]/).map((x) => x.trim()).filter(Boolean);
  }
  _afecta(lista, tipo) { return lista.includes("todo") || lista.includes(tipo); }

  /**
   * Aplica daño: Resistencia/Vulnerable → Blindaje → PE → PV (o PS).
   * @param {number} cantidad
   * @param {{tipo?:string, at?:number, mult?:number}} opts  at: 1 (AT1) o 2 (AT2); mult: p.ej. 0.5 si superó la salvación
   */
  async applyDamage(cantidad, { tipo = "cinetico", at = 0, mult = 1 } = {}) {
    let dmg = Math.floor(num(cantidad) * mult + (mult < 1 ? 0.5 : 0));
    const notas = [];
    const inmune = this._afecta(this._lista("inmune"), tipo);
    if (inmune) {
      await this._chatDano(`${this.name} es <b>Inmune</b> al daño ${BBB.TIPOS_DANO[tipo]?.label ?? tipo}.`);
      return 0;
    }
    if (at < 2) {
      const res = this.statuses.has("resistente") || this._afecta(this._lista("resistente"), tipo);
      const vul = this.statuses.has("vulnerable") || this._afecta(this._lista("vulnerable"), tipo);
      if (res && !vul) { dmg = Math.ceil(dmg / 2); notas.push("Resistente (÷2)"); }
      else if (vul && !res) { dmg *= 2; notas.push("Vulnerable (×2)"); }
    }
    const ignora = at >= 1 || BBB.IGNORAN_BLINDAJE.includes(tipo);
    const blind = ignora ? 0 : this.system.derived.blindaje;
    if (blind) notas.push(`Blindaje −${blind}`);
    dmg = Math.max(0, dmg - blind);

    const ag = this.system.aguante;
    const upd = {};
    let resto = dmg;
    let escudoRoto = false;
    const peIni = num(ag.pe.value);
    if (peIni > 0 && resto > 0) {
      const abs = Math.min(peIni, resto);
      upd["system.aguante.pe.value"] = peIni - abs;
      resto -= abs;
      escudoRoto = peIni - abs === 0 && num(ag.pe.max) > 0;
    }
    let fuera = false;
    if (resto > 0) {
      const pool = num(ag.pv.max) > 0 || num(ag.ps.max) === 0 ? "pv" : "ps";
      const nuevo = Math.max(0, num(ag[pool].value) - resto);
      upd[`system.aguante.${pool}.value`] = nuevo;
      fuera = nuevo === 0;
    }
    if (Object.keys(upd).length) await this.update(upd);

    await this._chatDano(
      `<b>${this.name}</b> recibe <b>${dmg}</b> de daño ${BBB.TIPOS_DANO[tipo]?.label ?? tipo}` +
      (notas.length ? ` <small>(${notas.join(", ")})</small>` : "") +
      (escudoRoto ? `<br><i>¡Escudo destruido!</i>` : "") + (fuera ? `<br><i>Fuera de combate.</i>` : "")
    );

    if (escudoRoto && this.type === "argonauta") await this.rollSuerte();
    if (fuera) {
      if (this.type === "argonauta") await this.toggleStatusEffect("garras", { active: true });
      else await this.toggleStatusEffect(CONFIG.specialStatusEffects.DEFEATED, { active: true, overlay: true });
    }
    return dmg;
  }

  _chatDano(html) {
    return ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `<div class="bbb-card"><div class="bbb-card-body">${html}</div></div>`
    });
  }

  /** Cura PV/PE/PS hasta el máximo. */
  async heal(cantidad, pool = "pv") {
    const p = this.system.aguante[pool];
    await this.update({ [`system.aguante.${pool}.value`]: Math.min(num(p.max), num(p.value) + num(cantidad)) });
  }

  /* -------------------------------------------- */
  /*  Turnos                                       */
  /* -------------------------------------------- */
  /** Al iniciar el turno: restaura PA y reduce los dados de enfriamiento. */
  async onTurnStart() {
    await this.update({ "system.pa.value": num(this.system.pa.max) });
    const ups = this.items
      .filter((i) => ["habilidad", "codigo"].includes(i.type) && num(i.system.cd) > 1)
      .map((i) => ({ _id: i.id, "system.cd": Math.max(1, num(i.system.cd) - 1) }));
    if (ups.length) await this.updateEmbeddedDocuments("Item", ups);
  }

  async gastarPA(n) {
    const pa = num(this.system.pa.value);
    if (n > pa) ui.notifications.warn(`${this.name} no tiene suficientes PA (${pa}/${n}).`);
    await this.update({ "system.pa.value": Math.max(0, pa - n) });
  }
}

export class BBBItem extends Item {
  /** Usar el objeto: atacar con un arma, activar habilidad/código, etc. */
  async use(event) {
    const actor = this.actor;
    if (!actor) return ui.notifications.warn("El objeto debe pertenecer a un personaje.");
    if (this.type === "arma") return R.rollAtaque(actor, this, event);
    if (["habilidad", "codigo", "dote"].includes(this.type)) return R.usarHabilidad(actor, this, event);
    if (this.type === "talento") return R.rollTalento(actor, this, event);
    return R.cardItem(actor, this);
  }
}
