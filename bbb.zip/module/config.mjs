/** Configuración y datos de reglas de Big Bang Breaker (Core Rulebook v1.0). */
export const BBB = {};

BBB.ATRIBUTOS = {
  for: "Fortaleza",
  dez: "Destreza",
  eng: "Energía",
  con: "Concentración",
  tech: "Tecnología"
};
BBB.ATRIBUTOS_ABBR = { for: "FOR", dez: "DEZ", eng: "ENG", con: "CON", tech: "TECH" };

/** Salvaciones: qué atributos usa cada una. */
BBB.SALVACIONES = {
  cuerpo: { label: "Cuerpo", attrs: ["for", "dez"] },
  espiritu: { label: "Espíritu", attrs: ["eng", "con"] },
  tech: { label: "Tecnología", attrs: ["tech"] }
};

/** Adiestramiento (ADT) por nivel: 0 | 1-2 → +1 | 3-4 → +2 ... 15 → +8 */
BBB.adt = (nivel) => {
  const n = Number(nivel) || 0;
  return n <= 0 ? 0 : Math.min(8, Math.ceil(n / 2));
};
BBB.tier = (nivel) => {
  const n = Number(nivel) || 0;
  return n <= 0 ? 0 : n <= 5 ? 1 : n <= 10 ? 2 : 3;
};

BBB.TIPOS_DANO = {
  cinetico: { label: "Cinético", fisico: true },
  explosivo: { label: "Explosivo", fisico: true },
  corrosivo: { label: "Corrosivo", fisico: true },
  sonico: { label: "Sónico", fisico: true },
  termico: { label: "Térmico", fisico: false },
  electromagnetico: { label: "Electromagnético", fisico: false },
  vacio: { label: "Vacío", fisico: false },
  estasis: { label: "Estasis", fisico: false },
  psionico: { label: "Psiónico", fisico: false },
  carmesi: { label: "Carmesí", fisico: false },
  estelar: { label: "Estelar", fisico: false }
};
/** El Blindaje no reduce estos tipos (además de armas con AT1/AT2). */
BBB.IGNORAN_BLINDAJE = ["corrosivo", "psionico"];
BBB.BLINDAJE_MAX = 4;

/** Especies (Core Rulebook, Compendio). pv/pe/ps = AGUANTE inicial. */
BBB.ESPECIES = {
  humano: { nombre: "Humano", pv: 10, pe: 0, ps: 0, todoPE: false, tamano: 1, bono: "+1 a un atributo a elección" },
  zarjhita: { nombre: "Zarjhita", pv: 14, pe: 0, ps: 0, todoPE: false, tamano: 1, bono: "+1 FOR o DEZ" },
  iso: { nombre: "ISO", pv: 0, pe: 10, ps: 0, todoPE: true, tamano: 1, bono: "+1 TECH" },
  starborn: { nombre: "Starborn", pv: 6, pe: 0, ps: 0, todoPE: false, tamano: 1, bono: "+1 ENG" },
  mazorh: { nombre: "Mázorh", pv: 8, pe: 0, ps: 0, todoPE: false, tamano: 0.5, bono: "+1 DEZ" },
  heatfallen: { nombre: "Heatfallen", pv: 10, pe: 0, ps: 0, todoPE: false, tamano: 1, bono: "+1 CON" },
  vulkkonita: { nombre: "Vulkkönita", pv: 0, pe: 0, ps: 14, todoPE: false, tamano: 2, bono: "+1 FOR o TECH" },
  custom: { nombre: "Personalizada", pv: 0, pe: 0, ps: 0, todoPE: false, tamano: 1, bono: "" }
};

/**
 * Clases. Aguante = base + (pvFor*FOR) + (pvAdt*ADT) ... según el bloque de cada clase.
 * Verifica contra tu libro: los multiplicadores se leen del bloque "AGUANTE INICIAL".
 */
BBB.CLASES = {
  legionario: { nombre: "Legionario", pvBase: 5, peBase: 5, pvFor: 0, pvAdt: 3, peFor: 4, peAdt: 0, velocidad: 5, dificultadBase: 10 },
  bladedancer: { nombre: "Bladedancer", pvBase: 5, peBase: 5, pvFor: 0, pvAdt: 3, peFor: 4, peAdt: 0, velocidad: 6, dificultadBase: 10 },
  warmonger: { nombre: "Warmonger", pvBase: 10, peBase: 10, pvFor: 4, pvAdt: 0, peFor: 0, peAdt: 3, velocidad: 4, dificultadBase: 10 },
  marksman: { nombre: "Marksman", pvBase: 4, peBase: 4, pvFor: 4, pvAdt: 0, peFor: 0, peAdt: 3, velocidad: 5, dificultadBase: 10 },
  novashifter: { nombre: "Novashifter", pvBase: 2, peBase: 4, pvFor: 3, pvAdt: 0, peFor: 0, peAdt: 4, velocidad: 5, dificultadBase: 10 },
  custom: { nombre: "Personalizada", pvBase: 0, peBase: 0, pvFor: 0, pvAdt: 0, peFor: 0, peAdt: 0, velocidad: 5, dificultadBase: 10 }
};

BBB.ORIGEN_DOTES = {
  especie: "Especie", linaje: "Linaje", clase: "Clase", doctrina: "Doctrina", nexo: "Nexo", armadura: "Armadura"
};
BBB.ACTIVACIONES = {
  pasiva: "Pasiva", accion: "Acción (PAU)", libre: "Acción Gratis", reaccion: "Reacción", hackeo: "Hackeo"
};
BBB.METODOS_CODIGO = { evocacion: "Evocación", permutador: "Permutador", abjurador: "Abjurador", sintaxis: "Sintaxis base" };

/** Condiciones de estado (Core Rulebook, "Condiciones de estado"). */
BBB.CONDICIONES = [
  ["alentado", "Alentado", "icons/svg/downgrade.svg"],
  ["paralizado", "Paralizado", "icons/svg/paralysis.svg"],
  ["aturdido", "Aturdido", "icons/svg/daze.svg"],
  ["silenciado", "Silenciado", "icons/svg/silenced.svg"],
  ["atontado", "Atontado", "icons/svg/stoned.svg"],
  ["nulificado", "Nulificado", "icons/svg/padlock.svg"],
  ["invisible", "Invisible", "icons/svg/invisible.svg"],
  ["escondido", "Escondido", "icons/svg/eye.svg"],
  ["tumbado", "Tumbado", "icons/svg/falling.svg"],
  ["cegado", "Cegado", "icons/svg/blind.svg"],
  ["mermado", "Mermado", "icons/svg/degen.svg"],
  ["agarrado", "Agarrado", "icons/svg/net.svg"],
  ["inmovilizado", "Inmovilizado", "icons/svg/anchor.svg"],
  ["vulnerable", "Vulnerable", "icons/svg/target.svg"],
  ["resistente", "Resistente", "icons/svg/shield.svg"],
  ["garras", "Garras de la Muerte", "icons/svg/skull.svg"]
];

/** Un ataque es crítico si el total de la tirada supera este valor. */
BBB.CRITICO_SOBRE = 20;
/** Falla por esta diferencia o más en una tirada de talento → decisión difícil. */
BBB.DECISION_DIFICIL = 3;
